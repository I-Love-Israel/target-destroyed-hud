import dev.targethud.CombatTracker;
import dev.targethud.LootGuard;
import java.util.List;
import java.util.UUID;

public class LootGuardTest {
    private static int checks;
    private static void check(boolean test, String why) {
        checks++;
        if (!test) throw new AssertionError(why);
    }
    private static LootGuard.Player at(UUID id, String name, double x, boolean dead) {
        return new LootGuard.Player(id, name, new CombatTracker.Point(x, 64, 0), dead);
    }
    private static final CombatTracker.Point BODY = new CombatTracker.Point(0, 64, 0);
    private static final java.util.function.Predicate<String> NO_FRIENDS = name -> false;

    public static void main(String[] args) {
        UUID victim = UUID.randomUUID(), other = UUID.randomUUID(), friend = UUID.randomUUID();

        // Enemy kill with nobody else near: locks for 1.5 s.
        LootGuard g = new LootGuard();
        g.enemyKilled(victim, BODY, List.of(at(victim, "Enemy", 0, true)), NO_FRIENDS, 1000);
        check(g.locked(1000), "enemy kill, nobody near -> locked");
        check(g.locked(2499), "lock still on at 1499 ms");
        check(!g.locked(2500), "lock ends after 1500 ms");

        // Another living enemy 20 blocks from the body: no lock.
        g = new LootGuard();
        g.enemyKilled(victim, BODY, List.of(at(other, "Other", 20, false)), NO_FRIENDS, 1000);
        check(!g.locked(1000), "other enemy 20 blocks away -> not locked");

        // Another enemy 35 blocks away: outside the scan, so locks.
        g = new LootGuard();
        g.enemyKilled(victim, BODY, List.of(at(other, "Other", 35, false)), NO_FRIENDS, 1000);
        check(g.locked(1000), "other enemy 35 blocks away -> locked");

        // Another enemy near the body but dead: ignored.
        g = new LootGuard();
        g.enemyKilled(victim, BODY, List.of(at(other, "Other", 5, true)), NO_FRIENDS, 1000);
        check(g.locked(1000), "dead enemy near body -> locked");

        // A friend near the body is not an enemy.
        g = new LootGuard();
        g.enemyKilled(victim, BODY, List.of(at(friend, "buddy", 5, false)), name -> name.equalsIgnoreCase("Buddy"), 1000);
        check(g.locked(1000), "only a friend near body -> locked");

        // Friend without any enemy around the kill still counts as an enemy when not a friend.
        g = new LootGuard();
        g.enemyKilled(victim, BODY, List.of(at(other, "Other", 5, false)), NO_FRIENDS, 1000);
        check(!g.locked(1000), "non-friend near body -> not locked");

        // The victim is ignored even if listed alive.
        g = new LootGuard();
        g.enemyKilled(victim, BODY, List.of(at(victim, "Enemy", 0, false)), NO_FRIENDS, 1000);
        check(g.locked(1000), "victim listed alive is not a blocker");

        // A friend's death always locks for 2 s.
        g = new LootGuard();
        g.friendDied(1000);
        check(g.locked(1000), "friend death -> locked");
        check(g.locked(2999), "friend lock still on at 1999 ms");
        check(!g.locked(3000), "friend lock ends after 2000 ms");

        // A longer lock is not shortened by a later shorter one.
        g = new LootGuard();
        g.friendDied(1000);
        g.enemyKilled(victim, BODY, List.of(), NO_FRIENDS, 1100);
        check(g.locked(2999), "later shorter lock does not shorten friend lock");

        // Reset clears any lock (used when the world changes).
        g.reset();
        check(!g.locked(1200), "reset clears the lock");

        System.out.println("LootGuardTest passed " + checks + " checks");
    }
}
