package dev.targethud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.DeltaTracker;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.protocol.game.ClientboundDamageEventPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.attribute.EnvironmentAttributes;
import org.slf4j.LoggerFactory;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

public final class TargetHud implements ClientModInitializer {
    private static final CombatTracker TRACKER = new CombatTracker();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final FontDescription FONT = new FontDescription.Resource(Identifier.fromNamespaceAndPath("targethud", "combat"));
    private static Config config = new Config();
    private static Object level;
    private static final List<Pending> pending = new ArrayList<>();
    private static final Map<UUID, Long> deadSeen = new HashMap<>();
    private static String message = "";
    private static boolean showingKill;
    private static long shownAt;
    private static long previewPopAt;
    private record Pending(UUID id, CombatTracker.Point point, boolean kill, long at) {}
    public static class Config {
        public boolean enabled = true;
        public boolean strictAttribution = false;
        public double scale = 0.80;
        public double verticalPosition = 0.36;
        public int durationMillis = 2200;
    }
    private static long now() { return System.nanoTime()/1_000_000; }
    private static CombatTracker.Point point(Vec3 v) { return new CombatTracker.Point(v.x, v.y, v.z); }
    private static Path configPath() { return FabricLoader.getInstance().getConfigDir().resolve("targethud.json"); }

    @Override public void onInitializeClient() {
        loadConfig();
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.fromNamespaceAndPath("targethud", "combat"), TargetHud::render);
        ClientTickEvents.END_CLIENT_TICK.register(TargetHud::tick);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) -> dispatcher.register(literal("targethud")
            .executes(ctx -> { ctx.getSource().sendFeedback(Component.literal("Target HUD: /targethud preview, kill, pop, toggle, strict, reload")); return 1; })
            .then(literal("preview").executes(ctx -> { show(true); previewPopAt = now()+2500; return 1; }))
            .then(literal("kill").executes(ctx -> { show(true); return 1; }))
            .then(literal("pop").executes(ctx -> { shownAt = 0; show(false); return 1; }))
            .then(literal("toggle").executes(ctx -> { config.enabled = !config.enabled; saveConfig(); ctx.getSource().sendFeedback(Component.literal("Target HUD " + (config.enabled ? "on" : "off"))); return 1; }))
            .then(literal("strict").executes(ctx -> { config.strictAttribution = !config.strictAttribution; saveConfig(); ctx.getSource().sendFeedback(Component.literal("Strict attribution " + (config.strictAttribution ? "on (server damage sources only)" : "off (crystal/anchor action matching enabled)"))); return 1; }))
            .then(literal("reload").executes(ctx -> { loadConfig(); ctx.getSource().sendFeedback(Component.literal("Target HUD config reloaded.")); return 1; }))));
        LoggerFactory.getLogger("targethud").info("Target HUD 1.0.1 initialized for Minecraft 26.2");
    }
    private static void loadConfig() {
        try {
            if (Files.exists(configPath())) {
                Config read = GSON.fromJson(Files.readString(configPath()), Config.class);
                if (read != null) config = read;
            } else saveConfig();
        } catch (Exception e) { LoggerFactory.getLogger("targethud").warn("Could not read targethud.json; using defaults", e); config = new Config(); }
        if (!Double.isFinite(config.scale)) config.scale = 0.80;
        if (!Double.isFinite(config.verticalPosition)) config.verticalPosition = .36;
        config.scale = Math.clamp(config.scale, .5, 3);
        config.verticalPosition = Math.clamp(config.verticalPosition, .1, .85);
        config.durationMillis = Math.clamp(config.durationMillis, 500, 6000);
    }
    private static void saveConfig() {
        try { Files.createDirectories(configPath().getParent()); Files.writeString(configPath(), GSON.toJson(config)); }
        catch (Exception e) { LoggerFactory.getLogger("targethud").warn("Could not save targethud.json", e); }
    }
    private static boolean ready() {
        Minecraft mc = Minecraft.getInstance();
        if (level != mc.level) {
            level = mc.level; TRACKER.clear(); pending.clear(); deadSeen.clear(); message = ""; previewPopAt = 0;
        }
        return mc.level != null && mc.player != null;
    }
    public static void attack(Entity target) {
        if (!ready()) return;
        if (target instanceof Player) TRACKER.attack(target.getUUID(), now());
        if (target instanceof EndCrystal) TRACKER.explosion(point(target.position()), 12, target.getId(), now());
    }
    public static void useAnchor(Player player, InteractionHand hand, BlockHitResult hit) {
        if (!ready() || player.isShiftKeyDown()) return;
        var mc = Minecraft.getInstance();
        var state = mc.level.getBlockState(hit.getBlockPos());
        if (!state.is(Blocks.RESPAWN_ANCHOR) || state.getValue(RespawnAnchorBlock.CHARGE) == 0) return;
        // A usable glowstone charge, off-hand charge, or Nether spawn set is not an explosion.
        if (state.getValue(RespawnAnchorBlock.CHARGE) < 4 && player.getItemInHand(hand).is(Items.GLOWSTONE)) return;
        if (hand == InteractionHand.MAIN_HAND && player.getOffhandItem().is(Items.GLOWSTONE)) return;
        Vec3 center = Vec3.atCenterOf(hit.getBlockPos());
        if (mc.level.environmentAttributes().getValue(EnvironmentAttributes.RESPAWN_ANCHOR_WORKS, center)) return;
        TRACKER.explosion(point(center), 10, -1, now());
    }
    public static void damage(ClientboundDamageEventPacket packet) {
        if (!ready()) return;
        var mc = Minecraft.getInstance();
        Entity victim = mc.level.getEntity(packet.entityId());
        if (!(victim instanceof Player) || victim == mc.player) return;
        var source = packet.getSource(mc.level);
        boolean ours = packet.sourceCauseId() == mc.player.getId() || packet.sourceDirectId() == mc.player.getId();
        boolean knownOther = source.getEntity() instanceof Player && source.getEntity() != mc.player;
        if (!ours && !knownOther && !config.strictAttribution && source.is(DamageTypeTags.IS_EXPLOSION)) {
            Vec3 origin = source.getSourcePosition();
            ours = TRACKER.matchesExplosion(point(victim.position()), origin == null ? null : point(origin), packet.sourceDirectId(), now());
        }
        TRACKER.damage(victim.getUUID(), ours, now());
    }
    public static void entityEvent(Entity entity, byte event) {
        if (!ready() || !(entity instanceof Player) || entity == Minecraft.getInstance().player) return;
        if (event == 3 || event == 35) pending.add(new Pending(entity.getUUID(), point(entity.position()), event == 3, now()));
    }
    public static void systemChat(Component text) {
        if (!ready()) return;
        var mc = Minecraft.getInstance();
        // Only anchored, known death-message forms; normal player chat is never inspected.
        String line = text.getString().replaceAll("§.", "").strip();
        String self = Pattern.quote(mc.player.getName().getString());
        for (Player other : mc.level.players()) {
            if (other == mc.player) continue;
            String target = Pattern.quote(other.getName().getString());
            if (line.matches("(?i)^"+target+" was (?:slain|killed|shot|blown up|finished off) by "+self+"(?: using .*)?[.!]?$" )
                || line.matches("(?i)^You (?:killed|eliminated) "+target+"[.!]?$")) {
                if (TRACKER.accept(other.getUUID(), true, now())) show(true);
            }
        }
    }
    private static void tick(Minecraft mc) {
        if (!ready()) return;
        long time = now();
        if (previewPopAt > 0 && time >= previewPopAt) { previewPopAt = 0; shownAt = 0; show(false); }
        // Some servers use health metadata instead of a death-status packet. Removal alone is never a kill.
        for (Player other : mc.level.players()) {
            if (other == mc.player) continue;
            if (other.isDeadOrDying()) {
                if (deadSeen.putIfAbsent(other.getUUID(), time) == null) entityEvent(other, (byte)3);
            } else deadSeen.remove(other.getUUID());
        }
        Iterator<Pending> iterator = pending.iterator();
        while (iterator.hasNext()) {
            Pending event = iterator.next();
            if (time-event.at < 100) continue;
            if (TRACKER.credited(event.id, event.point, time, config.strictAttribution) && TRACKER.accept(event.id, event.kill, time)) show(event.kill);
            iterator.remove();
        }
        deadSeen.values().removeIf(t -> time-t > 5000);
        TRACKER.prune(time);
    }
    private static void show(boolean kill) {
        long time = now();
        if (!kill && showingKill && time-shownAt < 1000) return;
        showingKill = kill; message = kill ? "Target destroyed" : "Critical hit"; shownAt = time;
    }
    private static void render(GuiGraphicsExtractor graphics, DeltaTracker delta) {
        if (!config.enabled || message.isEmpty() || Minecraft.getInstance().player == null) return;
        long age = now()-shownAt;
        if (age > config.durationMillis) return;
        float fade = Math.min(1f, age/90f) * Math.min(1f, (config.durationMillis-age)/450f);
        int alpha = Math.clamp((int)(fade*255), 0, 255);
        if (alpha < 5) return;
        var mc = Minecraft.getInstance();
        Component text = Component.literal(message).withStyle(s -> s.withFont(FONT));
        float scale = (float)config.scale;
        graphics.pose().pushMatrix();
        graphics.pose().translate(graphics.guiWidth()/2f, (float)(graphics.guiHeight()*config.verticalPosition));
        graphics.pose().scale(scale, scale);
        int x = -mc.font.width(text)/2;
        // Two-pixel soft dark edge, then warm red (kill) or off-white (critical hit).
        int shadow = ((int)(alpha*.7f)<<24);
        graphics.text(mc.font, text, x+1, 1, shadow, false);
        graphics.text(mc.font, text, x, 0, (alpha<<24) | (showingKill ? 0xF45142 : 0xF4F1E8), false);
        graphics.pose().popMatrix();
    }
}
