package dev.targethud.mixin;

import dev.targethud.TargetHud;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class PacketListenerMixin {
    // TAIL runs after vanilla's packet-thread guard; never touch the world on a Netty thread.
    @Inject(method="handleEntityEvent", at=@At("TAIL"))
    private void targethud$event(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        var level = Minecraft.getInstance().level;
        if (level != null) TargetHud.entityEvent(packet.getEntity(level), packet.getEventId());
    }
    @Inject(method="handleDamageEvent", at=@At("TAIL"))
    private void targethud$damage(ClientboundDamageEventPacket packet, CallbackInfo ci) { TargetHud.damage(packet); }
    @Inject(method="handleSystemChat", at=@At("TAIL"))
    private void targethud$chat(ClientboundSystemChatPacket packet, CallbackInfo ci) {
        if (!packet.overlay()) TargetHud.systemChat(packet.content());
    }
}
