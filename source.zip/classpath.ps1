param([string]$PrismRoot = "$env:APPDATA\PrismLauncher")
$paths = [Collections.Generic.List[string]]::new()
$paths.Add((Join-Path $PrismRoot 'libraries\com\mojang\minecraft\26.2\minecraft-26.2-client.jar'))
foreach ($meta in @('net.minecraft\26.2.json','net.fabricmc.fabric-loader\0.19.5.json','org.lwjgl3\3.4.1.json')) {
    $data = Get-Content (Join-Path $PrismRoot "meta\$meta") -Raw | ConvertFrom-Json
    foreach ($lib in $data.libraries) {
        if ($lib.rules -and -not ($lib.rules | Where-Object { $_.action -eq 'allow' -and ($_.os.name -eq 'windows' -or -not $_.os) })) { continue }
        $parts = $lib.name.Split(':')
        $folder = Join-Path $PrismRoot ('libraries\'+$parts[0].Replace('.','\')+'\'+$parts[1]+'\'+$parts[2])
        if (Test-Path $folder) { foreach ($f in (Get-ChildItem $folder -Filter '*.jar')) { $paths.Add($f.FullName) } }
        else { Write-Warning "Missing library folder: $folder" }
    }
}
$paths | Select-Object -Unique
