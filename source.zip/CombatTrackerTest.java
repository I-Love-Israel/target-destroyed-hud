import dev.targethud.CombatTracker;
import java.util.UUID;

public class CombatTrackerTest {
    private static int checks;
    private static void check(boolean test, String why) {
        checks++;
        if (!test) throw new AssertionError(why);
    }
    public static void main(String[] args) {
        var t = new CombatTracker();
        var a = UUID.randomUUID();
        var b = UUID.randomUUID();
        var near = new CombatTracker.Point(2, 0, 0);
        var center = new CombatTracker.Point(0, 0, 0);
        var far = new CombatTracker.Point(30, 0, 0);
        check(!t.credited(a, near, 1000, false), "Nearby players alone are not ours");
        t.attack(a, 1000);
        check(t.credited(a, near, 1100, false), "Recent melee fallback");
        check(!t.credited(a, near, 1100, true), "Strict ignores unconfirmed swings");
        check(!t.credited(b, near, 1100, false), "Other target not credited");
        check(!t.credited(a, near, 1800, false), "Swing expires");
        t.explosion(center, 12, 42, 2000);
        check(t.matchesExplosion(near, center, 42, 2200), "Our crystal and victim radius");
        check(!t.matchesExplosion(far, center, 42, 2200), "Outside blast radius");
        check(!t.matchesExplosion(near, far, 42, 2200), "Unrelated explosion position");
        check(!t.matchesExplosion(near, center, 43, 2200), "Other crystal source");
        check(!t.matchesExplosion(near, center, 42, 3000), "Old blast expires");
        t.damage(a, false, 2250);
        check(!t.credited(a, near, 2300, false), "Explicit other-source damage overrides action");
        t.damage(a, true, 2400);
        check(t.credited(a, near, 2500, true), "Authoritative local-source damage works strict");
        check(t.accept(a, false, 2500), "First pop");
        check(!t.accept(a, false, 2550), "Duplicate pop suppressed");
        check(t.accept(a, false, 2700), "Separate rapid pop allowed");
        check(t.accept(a, true, 2750), "Death immediately after pop");
        check(!t.accept(a, true, 2800), "Metadata and status death deduplicated");
        check(t.accept(b, true, 2800), "Multi-target kills independent");
        t.clear();
        check(!t.credited(a, near, 2900, false), "World switch clears credits");
        t.explosion(center, 10, -1, 3000);
        check(t.credited(a, near, 3100, false), "Anchor fallback");
        check(!t.credited(a, near, 3100, true), "Strict excludes anchor inference");
        t.prune(10000);
        check(!t.credited(a, near, 10000, false), "Cleanup expires all combat actions");
        System.out.println("PASS: " + checks + " combat-attribution checks");
    }
}
