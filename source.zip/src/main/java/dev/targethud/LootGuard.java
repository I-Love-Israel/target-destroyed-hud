package dev.targethud;

import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * Loot guard. After you kill an enemy player, world clicks lock for a moment if no other enemy stands
 * within SCAN_RADIUS of the body, so a reflex click cannot break or place on the loot. A friend's death
 * always locks. Friends are never counted as enemies. Kill attribution comes from {@link CombatTracker}
 * (the same credit that drives the kill notice), so this class only decides what happens next.
 */
public final class LootGuard {
    /** Another enemy this close to the body means the fight is still on, so no lock. */
    public static final double SCAN_RADIUS = 30;
    public static final long ENEMY_LOCK_MS = 1500;
    public static final long FRIEND_LOCK_MS = 2000;

    /** A loaded player: where they are and whether they are dead. */
    public record Player(UUID id, String name, CombatTracker.Point position, boolean dead) {}

    private volatile long lockedUntil;

    /** True while world clicks should be swallowed. */
    public boolean locked(long now) {
        return now < lockedUntil;
    }

    /** Forgets any lock; called when the world changes. */
    public void reset() {
        lockedUntil = 0;
    }

    /** A friend died. Always locks, whatever is around. */
    public void friendDied(long now) {
        lockFor(FRIEND_LOCK_MS, now);
    }

    /**
     * An enemy you killed died at {@code body}. {@code others} is every other loaded player, yourself
     * included or not; dead players and friends are ignored, and the victim is skipped by id.
     */
    public void enemyKilled(UUID victim, CombatTracker.Point body, List<Player> others, Predicate<String> isFriend, long now) {
        double radiusSquared = SCAN_RADIUS * SCAN_RADIUS;
        for (Player other : others) {
            if (other.dead() || other.id().equals(victim) || isFriend.test(other.name())) continue;
            if (other.position().distanceSquared(body) <= radiusSquared) return;
        }
        lockFor(ENEMY_LOCK_MS, now);
    }

    private void lockFor(long millis, long now) {
        lockedUntil = Math.max(lockedUntil, now + millis);
    }
}
