param([string]$PrismRoot = "$env:APPDATA\PrismLauncher")
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$jdk = Join-Path $PrismRoot 'java\java-runtime-epsilon\bin'
$mc = Join-Path $PrismRoot 'libraries\com\mojang\minecraft\26.2\minecraft-26.2-client.jar'
$cp = (@(& "$root\classpath.ps1" -PrismRoot $PrismRoot) + @(Get-ChildItem "$root\deps" -Filter '*.jar' | ForEach-Object FullName)) -join ';'
New-Item -ItemType Directory -Force "$root\classes" | Out-Null
$sources = @(Get-ChildItem "$root\src\main\java" -Recurse -Filter '*.java' | ForEach-Object FullName)
$arguments = @('--release', '25', '-proc:none', '-encoding', 'UTF-8', '-classpath', ('"'+$cp.Replace('\','/')+'"'), '-d', ('"'+"$root/classes".Replace('\','/')+'"')) + @($sources | ForEach-Object { '"'+$_.Replace('\','/')+'"' })
[IO.File]::WriteAllLines("$root\javac.args", $arguments)
& "$jdk\javac.exe" "@$root\javac.args"
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
Copy-Item "$root\src\main\resources\*" "$root\classes" -Recurse -Force
$output = Join-Path (Split-Path $root) 'outputs\target-destroyed-hud-1.0.1+26.2.jar'
& "$jdk\jar.exe" "-J-Djava.io.tmpdir=$root" --create --file $output -C "$root\classes" .
if ($LASTEXITCODE -ne 0) { throw 'Packaging failed' }
Write-Output 'Built target-destroyed-hud-1.0.1+26.2.jar'
