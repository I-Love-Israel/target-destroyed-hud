package dev.targethud;

import java.util.*;

/** Server damage is authoritative; short action windows are only a fallback. */
public final class CombatTracker {
    public record Point(double x, double y, double z) {
        double distanceSquared(Point p) {
            return (x-p.x)*(x-p.x)+(y-p.y)*(y-p.y)+(z-p.z)*(z-p.z);
        }
    }
    private record Hit(long time, boolean ours) {}
    private record Blast(long time, Point point, double radius, int entityId) {}
    private final Map<UUID, Hit> hits = new HashMap<>();
    private final Map<UUID, Long> swings = new HashMap<>();
    private final Map<UUID, Long> deaths = new HashMap<>();
    private final Map<UUID, Long> pops = new HashMap<>();
    private final List<Blast> blasts = new ArrayList<>();

    public void attack(UUID target, long now) { swings.put(target, now); }
    public void explosion(Point point, double radius, int entityId, long now) {
        prune(now);
        blasts.add(new Blast(now, point, radius, entityId));
    }
    public boolean matchesExplosion(Point victim, Point source, int directId, long now) {
        return blasts.stream().anyMatch(b -> now-b.time >= 0 && now-b.time <= 900
            && victim.distanceSquared(b.point) <= b.radius*b.radius
            && (source == null || source.distanceSquared(b.point) <= 9)
            && (directId < 0 || b.entityId < 0 || b.entityId == directId));
    }
    public void damage(UUID victim, boolean ours, long now) { hits.put(victim, new Hit(now, ours)); }
    public boolean credited(UUID victim, Point point, long now, boolean strict) {
        Hit hit = hits.get(victim);
        if (hit != null && now-hit.time <= 1500) return hit.ours;
        if (strict) return false;
        Long swing = swings.get(victim);
        return (swing != null && now-swing <= 650) || matchesExplosion(point, null, -1, now);
    }
    public boolean accept(UUID victim, boolean kill, long now) {
        Map<UUID, Long> events = kill ? deaths : pops;
        Long previous = events.get(victim);
        if (previous != null && now-previous < (kill ? 3000 : 150)) return false;
        events.put(victim, now);
        return true;
    }
    public void prune(long now) {
        hits.values().removeIf(h -> now-h.time > 5000);
        swings.values().removeIf(t -> now-t > 1000);
        deaths.values().removeIf(t -> now-t > 5000);
        pops.values().removeIf(t -> now-t > 5000);
        blasts.removeIf(b -> now-b.time > 1000);
    }
    public void clear() { hits.clear(); swings.clear(); deaths.clear(); pops.clear(); blasts.clear(); }
}
