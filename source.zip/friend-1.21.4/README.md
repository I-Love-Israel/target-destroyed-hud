# Target Destroyed HUD — Fabric 1.21.4

This is the separate friend build, not an update for Minecraft 26.2.

Install `target-destroyed-hud-1.0.1+1.21.4.jar` into the friend's 1.21.4 `mods`
folder alongside Fabric API 0.119.3+1.21.4 or newer for that same Minecraft version.
Requires Fabric Loader 0.16.10 or newer and Java 21 or newer.

Run `/targethud preview` in a world to preview the kill and totem-pop messages.
Other commands: `/targethud kill`, `/targethud pop`, `/targethud toggle`,
`/targethud strict`, `/targethud reload`.

Appearance: centered War Thunder-inspired red `Target destroyed` and off-white
`Critical hit`, with bundled Fira Sans Condensed. This is not a verified exact
copy of the original War Thunder typeface.

Crystal/anchor attribution uses server damage sources plus recent local actions.
When servers omit the attacker, action matching is approximate and may misattribute
events in crowds or under lag. Strict mode uses only server source attribution.
Donut SMP and mcpvp.com have not been live-tested.

To build on Windows, set JAVA_HOME to a JDK 21 installation and run
`gradlew.bat build`. Loom remaps the finished mod for normal Fabric installations.
Use the JAR without `-dev` or `-sources` from `build/libs`.

The 26.2 build and its installed copy are kept separate and unchanged.
